#!/bin/bash
# ============================================
# install-cup.sh - Instalador do Cup
# ============================================
# Instala o gerenciador de pacotes Cup para Tea Language
# Suporta: Bash, Zsh, Fish

echo "🍵 Cup - Tea Package Manager Installer"
echo "======================================"
echo ""

# Detecta o sistema operacional
if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    OS="linux"
elif [[ "$OSTYPE" == "darwin"* ]]; then
    OS="macos"
else
    echo "❌ Sistema operacional não suportado: $OSTYPE"
    exit 1
fi

echo "[*] Sistema detectado: $OS"
echo ""

# Define diretório de instalação
INSTALL_DIR="$HOME/.local/bin"

# Cria diretório se não existir
if [ ! -d "$INSTALL_DIR" ]; then
    echo "[*] Criando diretório: $INSTALL_DIR"
    mkdir -p "$INSTALL_DIR"
fi

# Copia o Cup
echo "[*] Instalando Cup em: $INSTALL_DIR/cup"
cp "$(dirname "$0")/../cup" "$INSTALL_DIR/cup"

# Torna executável
chmod +x "$INSTALL_DIR/cup"

echo "[✓] Cup instalado!"
echo ""

# ============================================
# CONFIGURAR SHELLS
# ============================================

echo "[*] Configurando shells..."
echo ""

# BASH
if [ -f "$HOME/.bashrc" ]; then
    if ! grep -q "/.local/bin" "$HOME/.bashrc" 2>/dev/null; then
        echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$HOME/.bashrc"
        echo "[✓] Bash configurado (~/.bashrc)"
    else
        echo "[*] Bash já estava configurado"
    fi
else
    echo "[!] ~/.bashrc não encontrado (Bash não instalado?)"
fi

# ZSH
if [ -f "$HOME/.zshrc" ]; then
    if ! grep -q "/.local/bin" "$HOME/.zshrc" 2>/dev/null; then
        echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$HOME/.zshrc"
        echo "[✓] Zsh configurado (~/.zshrc)"
    else
        echo "[*] Zsh já estava configurado"
    fi
else
    echo "[!] ~/.zshrc não encontrado (Zsh não instalado?)"
fi

# FISH
if [ -d "$HOME/.config/fish" ]; then
    FISH_CONFIG="$HOME/.config/fish/config.fish"
    mkdir -p "$HOME/.config/fish"
    
    if [ ! -f "$FISH_CONFIG" ]; then
        touch "$FISH_CONFIG"
    fi
    
    if ! grep -q "/.local/bin" "$FISH_CONFIG" 2>/dev/null; then
        echo 'set -gx PATH $HOME/.local/bin $PATH' >> "$FISH_CONFIG"
        echo "[✓] Fish configurado (~/.config/fish/config.fish)"
    else
        echo "[*] Fish já estava configurado"
    fi
else
    echo "[!] ~/.config/fish não encontrado (Fish não instalado?)"
fi

echo ""
echo "======================================"
echo "[✓] Cup instalado com sucesso!"
echo ""
echo "Próximos passos:"
echo "  1. cup update          # Atualiza repositório de extensões"
echo "  2. cup list            # Lista pacotes disponíveis"
echo "  3. cup install <pkg>   # Instala um pacote"
echo ""
echo "Documentação: https://github.com/skylikeinovation/tea-extensions"
echo ""

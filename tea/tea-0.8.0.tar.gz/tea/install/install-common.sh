#!/bin/sh
# Funções compartilhadas de instalação do Tea

INSTALL_DIR="${TEA_INSTALL_BIN:-$HOME/.local/bin}"
TEA_HOME="${TEA_HOME:-$HOME/.local/lib/tea}"
INSTALL_COMMON_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$INSTALL_COMMON_DIR/.." && pwd)"

tea_find_lua() {
    local cmd
    for cmd in lua lua5.4 lua5.3 lua5.2 lua5.1; do
        if command -v "$cmd" &> /dev/null; then
            echo "$cmd"
            return 0
        fi
    done
    return 1
}

tea_install_core() {
    if [ ! -f "$REPO_ROOT/src/tea.lua" ] || [ ! -f "$REPO_ROOT/src/vm.lua" ]; then
        echo "❌ Erro: Execute o instalador na raiz do projeto Tea."
        return 1
    fi

    if [ ! -f "$REPO_ROOT/tea" ]; then
        echo "❌ Erro: Script 'tea' não encontrado em $REPO_ROOT"
        return 1
    fi

    mkdir -p "$INSTALL_DIR" "$TEA_HOME/src" || return 1

    echo "[*] Copiando compilador e VM..."
    cp "$REPO_ROOT/src/tea.lua" "$TEA_HOME/src/" || return 1
    cp "$REPO_ROOT/src/vm.lua" "$TEA_HOME/src/" || return 1

    echo "[*] Instalando comando tea em $INSTALL_DIR..."
    sed "s|TEA_HOME=\"\${TEA_HOME:-\$HOME/Documentos/skylikeProjects/tea}\"|TEA_HOME=\"\${TEA_HOME:-$HOME/.local/lib/tea}\"|" \
        "$REPO_ROOT/tea" > "$INSTALL_DIR/tea" || return 1
    chmod +x "$INSTALL_DIR/tea" || return 1

    if [ -f "$REPO_ROOT/cup-official/cup" ]; then
        echo "[*] Instalando Cup..."
        cp "$REPO_ROOT/cup-official/cup" "$INSTALL_DIR/cup" || return 1
        chmod +x "$INSTALL_DIR/cup" || return 1
    fi

    return 0
}

tea_warn_lua() {
    local lua_cmd
    if lua_cmd="$(tea_find_lua)"; then
        echo "[+] Lua encontrado: $lua_cmd"
        return 0
    fi

    echo ""
    echo "⚠️  Lua não encontrado — o comando 'tea' foi instalado, mas não vai rodar até instalar o Lua."
    echo "    Instale com o gestor de pacotes da sua distro, por exemplo:"
    echo "      sudo dnf install lua        # Fedora"
    echo "      sudo apt install lua5.4     # Debian/Ubuntu"
    echo "      sudo pacman -S lua          # Arch"
    echo ""
    return 1
}

tea_ensure_path_bash() {
    if [ -f "$HOME/.bashrc" ] && ! grep -q '$HOME/.local/bin' "$HOME/.bashrc" 2>/dev/null; then
        echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$HOME/.bashrc"
        echo "[+] PATH adicionado ao ~/.bashrc"
    fi
}

tea_ensure_path_zsh() {
    if [ -f "$HOME/.zshrc" ] && ! grep -q '$HOME/.local/bin' "$HOME/.zshrc" 2>/dev/null; then
        echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$HOME/.zshrc"
        echo "[+] PATH adicionado ao ~/.zshrc"
    fi
}

tea_ensure_path_fish() {
    local fish_config="$HOME/.config/fish/config.fish"
    mkdir -p "$HOME/.config/fish"
    touch "$fish_config"
    if ! grep -q '$HOME/.local/bin' "$fish_config" 2>/dev/null; then
        echo 'fish_add_path $HOME/.local/bin' >> "$fish_config"
        echo "[+] PATH adicionado ao $fish_config"
    else
        echo "[*] PATH já está no config.fish"
    fi
}

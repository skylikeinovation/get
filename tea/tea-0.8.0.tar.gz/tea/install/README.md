# Instalação e Atualização do Tea

## Instalação Inicial

### Linux/macOS

```bash
# Clone o repositório
git clone https://github.com/seu-usuario/tea.git
cd tea

# Execute o instalador
bash install/install-bash.sh
```

### Windows

```bash
cd tea
install\install.bat
```

### Fish Shell

```bash
bash install/install-fish.sh
```

## Atualizar instalação

Depois de mudar o compilador ou a VM, rode de novo o instalador do teu shell:

```bash
bash install/install-bash.sh   # ou install-fish.sh / install-zsh.sh
```

## Uso

Depois de instalado, use em qualquer lugar:

```bash
# Compila e executa
tea programa.tea

# Apenas compila
tea -c programa.tea

# Executa bytecode
tea -r programa.teac

# Compila todos .tea no diretório
tea build

# Mostra ajuda
tea help
```

## Desenvolvimento

Durante o desenvolvimento, você pode:

1. Editar os arquivos em `src/`
2. Testar localmente com `lua src/tea.lua programa.tea` ou `./tea programa.tea`
3. Quando estiver pronto, rodar de novo o instalador (`install/install-*.sh`)
4. Testar com `tea programa.tea`

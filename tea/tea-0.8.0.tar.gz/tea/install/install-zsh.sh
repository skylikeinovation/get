#!/bin/sh
# Instalador do Tea Language (Zsh)

set -e
cd "$(dirname "$0")/.."
# shellcheck source=install-common.sh
source install/install-common.sh

echo "🍵 Instalando Tea Language (Zsh)..."
echo ""

tea_install_core
tea_warn_lua || true
tea_ensure_path_zsh

echo ""
echo "✅ Instalação completa!"
echo ""
echo "  tea <arquivo.tea>     # compila e executa"
echo "  tea -c <arquivo.tea>  # só compila"
echo "  tea help"
echo ""
echo "Ative o PATH neste terminal:"
echo "  export PATH=\"\$HOME/.local/bin:\$PATH\""
echo ""
